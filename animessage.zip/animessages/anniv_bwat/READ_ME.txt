Pour le lancer, suis ses étapes l'une après l'autre :

1) Appuie sur la touche Windows de ton clavier, tape "cmd" (sans les guillemets), puis touche Enter
2) Glisse animessage.exe dans l'invite de commandes
3) Ajoute un espace, puis tape "-f" (sans les guillemets)
4) Ajoute un espace, puis glisse anniv_bwat.txt dans l'invite de commandes.
5) Appuie sur touche Enter, et enjoy ;)